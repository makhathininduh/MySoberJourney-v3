package com.example.mysoberjourney

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

class MainActivity:Activity(){
 private lateinit var p:SharedPreferences
 private lateinit var root:LinearLayout
 private val fmt=SimpleDateFormat("yyyy-MM-dd",Locale.US)
 private val mf=SimpleDateFormat("MMMM yyyy",Locale.US)
 private var shown=Calendar.getInstance()
 private val name="Ndumiso"

 override fun onCreate(b:Bundle?){super.onCreate(b);p=getSharedPreferences("journey",0);ui();requestNotifications()}
 private fun ui(){root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,18,22,18);setBackgroundColor(Color.rgb(9,21,13))};setContentView(root);render()}
 private fun tv(s:String,z:Float,b:Boolean=false)=TextView(this).apply{text=s;textSize=z;setTextColor(Color.WHITE);setPadding(0,5,0,5);if(b)setTypeface(typeface,1)}
 private fun btn(s:String)=Button(this).apply{text=s;setTextColor(Color.WHITE);setAllCaps(false)}

 private fun render(){
  root.removeAllViews()
  root.addView(tv("My Sober Journey",29f,true))
  root.addView(tv("Good to see you, $name. 🌱",17f))
  val streak=streak()
  val hero=tv("🔥  $streak\nDAY${if(streak==1)"" else "S"} ALCOHOL-FREE",31f,true)
  hero.setGravity(Gravity.CENTER);hero.setPadding(10,20,10,20);hero.setBackgroundColor(Color.rgb(24,55,31));root.addView(hero)

  val today=fmt.format(Date());val done=p.getBoolean("day_$today",false)
  val todayBtn=btn(if(done)"✓  TODAY COMPLETED" else "✓  I DIDN'T DRINK TODAY")
  todayBtn.setOnClickListener{p.edit().putBoolean("day_$today",!done).apply();if(!done){schedule();milestoneIfNeeded(streak+1)};render()}
  root.addView(todayBtn)

  root.addView(tv("🏆 Best: ${best()} days    •    ✅ Total: ${total()} days",15f,true))
  root.addView(tv(message(streak),15f))

  val progress=btn("📈  VIEW MY PROGRESS")
  progress.setOnClickListener{progressDialog()};root.addView(progress)

  val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  val l=btn("‹");val title=tv(mf.format(shown.time),19f,true);title.gravity=17;val r=btn("›")
  nav.addView(l,LinearLayout.LayoutParams(55,55));nav.addView(title,LinearLayout.LayoutParams(0,55,1f));nav.addView(r,LinearLayout.LayoutParams(55,55))
  l.setOnClickListener{shown.add(Calendar.MONTH,-1);render()};r.setOnClickListener{shown.add(Calendar.MONTH,1);render()};root.addView(nav)
  root.addView(calendar())

  val note=btn("📝  TODAY'S JOURNAL");note.setOnClickListener{noteDialog(today)};root.addView(note)
  val rem=btn("🔔  CHANGE REMINDER TIME");rem.setOnClickListener{timeDialog()};root.addView(rem)
  root.addView(tv("Your journey is private and saved on this phone.",12f))
 }

 private fun calendar():GridLayout{
  val g=GridLayout(this).apply{columnCount=7}
  listOf("S","M","T","W","T","F","S").forEach{g.addView(tv(it,12f,true),cell())}
  val c=shown.clone() as Calendar;c.set(Calendar.DAY_OF_MONTH,1);repeat(c.get(Calendar.DAY_OF_WEEK)-1){g.addView(TextView(this),cell())}
  for(d in 1..c.getActualMaximum(Calendar.DAY_OF_MONTH)){
   val k=String.format(Locale.US,"%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,d);val yes=p.getBoolean("day_$k",false)
   val b=btn(if(yes)"✓ $d" else "$d");b.textSize=13f;if(yes)b.setTextColor(Color.rgb(115,220,130));b.setOnClickListener{p.edit().putBoolean("day_$k",!yes).apply();render()};g.addView(b,cell())
  };return g
 }
 private fun cell()=GridLayout.LayoutParams().apply{width=0;height=54;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(2,2,2,2)}

 private fun progressDialog(){
  val s=streak();val b=best();val t=total();val milestones=listOf(1,3,7,14,30,60,90,100,180,365)
  val reached=milestones.filter{t>=it}.joinToString(" • "){it.toString()}
  AlertDialog.Builder(this).setTitle("$name's Progress")
   .setMessage("🔥 Current streak: $s days\n🏆 Best streak: $b days\n✅ Alcohol-free days: $t\n\nMilestones reached:\n${if(reached.isBlank())"Your first milestone is waiting for you." else reached+" days"}")
   .setPositiveButton("Keep going!"){_,_->}.show()
 }
 private fun noteDialog(k:String){
  val e=EditText(this);e.setText(p.getString("note_$k",""));e.hint="What are you proud of today?";e.minLines=5
  AlertDialog.Builder(this).setTitle("$name's journal").setView(e).setPositiveButton("Save"){_,_->p.edit().putString("note_$k",e.text.toString()).apply()}.setNegativeButton("Cancel",null).show()
 }
 private fun timeDialog(){
  val tp=TimePicker(this);tp.setIs24HourView(false)
  AlertDialog.Builder(this).setTitle("Nightly congratulations").setMessage("Choose when $name should receive his daily achievement reminder.").setView(tp)
   .setPositiveButton("Set"){_,_->p.edit().putInt("hour",tp.hour).putInt("minute",tp.minute).apply();schedule()}.setNegativeButton("Cancel",null).show()
 }
 private fun total()=p.all.keys.count{it.startsWith("day_")&&p.getBoolean(it,false)}
 private fun streak():Int{var n=0;val c=Calendar.getInstance();while(p.getBoolean("day_${fmt.format(c.time)}",false)){n++;c.add(Calendar.DAY_OF_YEAR,-1)};return n}
 private fun best():Int{val d=p.all.keys.filter{it.startsWith("day_")&&p.getBoolean(it,false)}.mapNotNull{runCatching{fmt.parse(it.removePrefix("day_"))!!}.getOrNull()}.sorted();if(d.isEmpty())return 0;var x=1;var q=1;for(i in 1 until d.size){if((d[i].time-d[i-1].time)/86400000==1L){q++;x=max(x,q)}else q=1};return x}
 private fun message(s:Int)=when{s>=365->"🏆 Ndumiso, one year is an extraordinary achievement.";s>=100->"🌟 Ndumiso, 100 days! Look how far you've come.";s>=90->"💪 Ndumiso, 90 days of progress.";s>=60->"🔥 Ndumiso, 60 days! Keep protecting your progress.";s>=30->"🎉 Ndumiso, one month alcohol-free.";s>=14->"⭐ Ndumiso, two weeks! You're building momentum.";s>=7->"🎉 Ndumiso, one whole week!";s>=1->"🌱 Well done, Ndumiso. Today counts.";else->"Ndumiso, start with today. One day at a time."}
 private fun milestoneIfNeeded(s:Int){if(listOf(1,3,7,14,30,60,90,100,180,365).contains(s))AlertDialog.Builder(this).setTitle("🏆 AMAZING, NDUMISO!").setMessage("You've reached $s alcohol-free day${if(s==1)"" else "s"}.\n\nTake a moment to be proud of yourself.").setPositiveButton("I'm proud of this!"){_,_->}.show()}
 private fun requestNotifications(){if(android.os.Build.VERSION.SDK_INT>=33)requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),50)}
 private fun schedule(){val c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,p.getInt("hour",21));c.set(Calendar.MINUTE,p.getInt("minute",0));c.set(Calendar.SECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);val pi=PendingIntent.getBroadcast(this,12,Intent(this,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);(getSystemService(ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi)}
}
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent?){val id="daily";val n=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;if(android.os.Build.VERSION.SDK_INT>=26)n.createNotificationChannel(NotificationChannel(id,"Daily achievement",NotificationManager.IMPORTANCE_DEFAULT));val x=androidx.core.app.NotificationCompat.Builder(c,id).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🎉 Well done, Ndumiso!").setContentText("Another alcohol-free day completed. Be proud of today's achievement.").setAutoCancel(true).build();n.notify(12,x)}}
